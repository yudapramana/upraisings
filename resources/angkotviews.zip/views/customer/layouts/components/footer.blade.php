<footer class="text-center p-4"> © 2025 AngkotApp | Registered in the Directorate General of Intellectual Property of the Republic of Indonesia.</footer>
