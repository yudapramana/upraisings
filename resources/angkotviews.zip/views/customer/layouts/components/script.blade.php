<script src="{{ asset('/') }}nadist/assets/libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="{{ asset('/') }}nadist/assets/libs/popper.js/dist/umd/popper.min.js"></script>
<script src="{{ asset('/') }}nadist/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
