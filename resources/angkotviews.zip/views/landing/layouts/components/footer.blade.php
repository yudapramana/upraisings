<style>
    #footer {
        height: 10vh;
    }
</style>
<div id="footer">
    <footer class="text-center p-4"> © 2025 AngkotApp</footer>
</div>
